#to find the largest and smallest no of the list

lst = [8,2,9,3,7]

print("The largest element of the list is ",max(lst))

print("The smallest element of the list is ",min(lst))
