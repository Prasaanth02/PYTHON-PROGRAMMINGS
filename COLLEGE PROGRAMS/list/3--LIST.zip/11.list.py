list1 = ["Mike", "", "Emma", "Kelly", "", "Brad"]
#remove empty strings
list2 = list(filter(None,list1))
print(list2)
