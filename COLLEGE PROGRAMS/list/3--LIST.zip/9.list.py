
list = [5, 10, 15, 200, 25, 50, 20]

a = int(input("Enter the element: "))
position = int(input("Enter the position: "))

# Insert the element
list.insert(position, a)

print("List:", list)
