list = [5, 10, 15, 200, 25, 50, 20]

# Calculate the range of the list
range = max(list) - min(list)

print("Range of the list:", range)
