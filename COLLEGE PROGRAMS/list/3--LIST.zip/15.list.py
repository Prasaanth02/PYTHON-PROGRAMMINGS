list = []

# Check if the list is empty
if not list:
    print("The list is empty.")
else:
    print("The list is not empty.")
