#sum of the list

lst = [8,2,9,3,7]#gn list

ans = int()#declaring that the ans in an integer

for i in lst:
    ans = ans + i

#output
print(ans)
    
 
