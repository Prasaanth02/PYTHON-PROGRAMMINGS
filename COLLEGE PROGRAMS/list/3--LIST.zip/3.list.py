#to reverse the order of the elements in the list
lst = ['A','P','B','Q','C','D']

print(lst[::-1])
