list = [3, 6, 4, 5, 6, 7]

list.sort()

# Find the second smallest element
second_smallest = list[1]

print("The second smallest element is:", second_smallest)
