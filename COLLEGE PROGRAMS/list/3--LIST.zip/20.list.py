import random

list = [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Shuffle the list randomly
random.shuffle(list)

print("Shuffled list:",list)
