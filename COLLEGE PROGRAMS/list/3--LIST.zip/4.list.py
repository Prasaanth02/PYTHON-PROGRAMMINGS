#to find the index of the elements

lst = ['A','P','B','Q','C','D']

for i in lst:
    print(lst.index(i))
    
