list = [3, 6, 4, 5, 6, 7]

# Initialize
product = 1

# Multiply each element
for num in list:
    product *= num

print("The product is:", product)
